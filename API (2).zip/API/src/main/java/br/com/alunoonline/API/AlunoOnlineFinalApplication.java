package br.com.alunoonline.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlunoOnlineFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlunoOnlineFinalApplication.class, args);
	}

}
